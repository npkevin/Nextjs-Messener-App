import { useState } from 'react'

import styles from '../styles/Authentication.module.css'

const Authentication = (props: any): JSX.Element => {

    // State
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    // Functions
    const login = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();


    }

    // Render
    return (
        <form className={styles.container} onSubmit={login}>
            <input
                type="username"
                placeholder='Username'
                value={username}
                onChange={event => setUsername(event.target.value)}
            />
            <input
                type="password"
                placeholder='Password'
                value={password}
                onChange={event => setPassword(event.target.value)}
            />
            <button type="submit" disabled={!username || !password}>Login</button>
        </form>
    )
}

export default Authentication