import Authentication from '../components/Authentication'
import styles from '../styles/SideMenu.module.css'


const SideMenu = (props: any): JSX.Element => {
    return (
        <div className={styles.container}>
            <Authentication />
        </div>
    )
}

export default SideMenu