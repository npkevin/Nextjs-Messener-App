import React from 'react'
import Message, { tMessage } from './Message'

import styles from '../../styles/Messenger.module.css'

type ConvoProps = {
    messages: tMessage[]
}
// TODO: add keys as message id from mongodb
const ConversationView = (props: ConvoProps): JSX.Element => {
    return (
        <div className={styles.messageHistory}>
            {props.messages.map(message => {
                return <Message message={message} />
            })}
        </div>
    )
}

export default ConversationView