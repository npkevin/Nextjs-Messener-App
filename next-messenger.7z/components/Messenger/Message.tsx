import styles from '../../styles/Messenger.module.css'

export type tMessage = {
    posted: Date,
    updated: Date
    value: string,
    sent?: boolean
}

const Message = (props: { message: tMessage }): JSX.Element => {
    // TODO:
    // - Add Dates (posted/updated)
    // - Read Status
    return (
        <div className={styles.message + (props.message.sent ? (" " + styles.message_sent) : " ")}>
            {props.message.value}
        </div >
    )
}


export default Message;