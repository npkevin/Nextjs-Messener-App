import React from 'react'
import styles from '../../styles/Messenger.module.css'
import { tMessage } from './Message'
import ConversationView from './ConversationView'
import Messenger from './Messenger'

const MessengerView = (): JSX.Element => {

    // Temporary Testing Data
    // TODO: Fetch from messages from conversation via api
    const getMessages = (): tMessage[] => {
        return [
            {
                posted: new Date(),
                updated: new Date(),
                value: "Good morning 🤗",
                sent: true
            }
            ,
            {
                posted: new Date(),
                updated: new Date(),
                value: "Morning 😴"
            }
        ]
    }

    return (
        <div className={styles.container}>
            <StatusView />
            <ConversationView messages={getMessages()} />
            <Messenger />
        </div>
    )
}

const StatusView = (): JSX.Element => {
    return (
        <div className={styles.recipient_container}>
            <img
                src="profile.png" alt=""
                draggable={false}
                onDragStart={e => e.preventDefault()} // Firefox support
            />
            <div className={styles.recipient}>
                <span className={styles.recipient__name}>Jane Doe</span>
                <span className={styles.recipient__status}>{"online"}</span>
            </div>
        </div>
    )
}

export default MessengerView;