"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/conv";
exports.ids = ["pages/api/conv"];
exports.modules = {

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ "(api)/./pages/api/conv.ts":
/*!***************************!*\
  !*** ./pages/api/conv.ts ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongodb */ \"mongodb\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);\n\nconst uri = \"mongodb://127.0.0.1:27017/\";\nconst client = new mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient(uri);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{\n    if (req.method === \"GET\") {\n        try {\n            console.log(req.query[\"convo-uid\"]);\n            res.status(200).json({\n                test: 123456\n            });\n        } catch (err) {\n            console.error(err);\n        }\n    } else if (req.method === \"PUT\" && req.headers[\"content-type\"] === \"application/json\") {\n        try {\n            await client.connect();\n            const db = client.db(\"conversations\");\n            const convo_uid = req.query[\"convo-uid\"];\n            console.log(convo_uid);\n            console.log(req.body.message);\n            res.status(201).send({});\n        } catch (err) {\n            console.error(err);\n            return;\n        }\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvY29udi50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBcUM7QUFHckMsS0FBSyxDQUFDQyxHQUFHLEdBQUcsQ0FBNEI7QUFDeEMsS0FBSyxDQUFDQyxNQUFNLEdBQUcsR0FBRyxDQUFDRixnREFBVyxDQUFDQyxHQUFHO0FBRWxDLGlFQUFNLE9BQWdCRSxHQUFtQixFQUFFQyxHQUFvQixHQUFLLENBQUM7SUFDakUsRUFBRSxFQUFFRCxHQUFHLENBQUNFLE1BQU0sS0FBSyxDQUFLLE1BQUUsQ0FBQztRQUN2QixHQUFHLENBQUMsQ0FBQztZQUNEQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0osR0FBRyxDQUFDSyxLQUFLLENBQUMsQ0FBVztZQUNqQ0osR0FBRyxDQUFDSyxNQUFNLENBQUMsR0FBRyxFQUFFQyxJQUFJLENBQUMsQ0FBQztnQkFBQ0MsSUFBSSxFQUFFLE1BQU07WUFBQyxDQUFDO1FBQ3pDLENBQUMsQ0FDRCxLQUFLLEVBQUVDLEdBQUcsRUFBRSxDQUFDO1lBQ1ROLE9BQU8sQ0FBQ08sS0FBSyxDQUFDRCxHQUFHO1FBQ3JCLENBQUM7SUFDTCxDQUFDLE1BQU0sRUFBRSxFQUFFVCxHQUFHLENBQUNFLE1BQU0sS0FBSyxDQUFLLFFBQUlGLEdBQUcsQ0FBQ1csT0FBTyxDQUFDLENBQWMsbUJBQU0sQ0FBa0IsbUJBQUUsQ0FBQztRQUNwRixHQUFHLENBQUMsQ0FBQztZQUNELEtBQUssQ0FBQ1osTUFBTSxDQUFDYSxPQUFPO1lBQ3BCLEtBQUssQ0FBQ0MsRUFBRSxHQUFHZCxNQUFNLENBQUNjLEVBQUUsQ0FBQyxDQUFlO1lBRXBDLEtBQUssQ0FBQ0MsU0FBUyxHQUFHZCxHQUFHLENBQUNLLEtBQUssQ0FBQyxDQUFXO1lBQ3ZDRixPQUFPLENBQUNDLEdBQUcsQ0FBQ1UsU0FBUztZQUNyQlgsT0FBTyxDQUFDQyxHQUFHLENBQUNKLEdBQUcsQ0FBQ2UsSUFBSSxDQUFDQyxPQUFPO1lBRTVCZixHQUFHLENBQUNLLE1BQU0sQ0FBQyxHQUFHLEVBQUVXLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDM0IsQ0FBQyxDQUNELEtBQUssRUFBRVIsR0FBRyxFQUFFLENBQUM7WUFDVE4sT0FBTyxDQUFDTyxLQUFLLENBQUNELEdBQUc7WUFDakIsTUFBTTtRQUNWLENBQUM7SUFDTCxDQUFDO0FBQ0wsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25leHQtbWVzc2VuZ2VyLy4vcGFnZXMvYXBpL2NvbnYudHM/ZTQxZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gXCJtb25nb2RiXCI7XHJcbmltcG9ydCB0eXBlIHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gXCJuZXh0XCJcclxuXHJcbmNvbnN0IHVyaSA9IFwibW9uZ29kYjovLzEyNy4wLjAuMToyNzAxNy9cIlxyXG5jb25zdCBjbGllbnQgPSBuZXcgTW9uZ29DbGllbnQodXJpKVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgKHJlcTogTmV4dEFwaVJlcXVlc3QsIHJlczogTmV4dEFwaVJlc3BvbnNlKSA9PiB7XHJcbiAgICBpZiAocmVxLm1ldGhvZCA9PT0gXCJHRVRcIikge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcS5xdWVyeVtcImNvbnZvLXVpZFwiXSlcclxuICAgICAgICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oeyB0ZXN0OiAxMjM0NTYgfSlcclxuICAgICAgICB9XHJcbiAgICAgICAgY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycilcclxuICAgICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHJlcS5tZXRob2QgPT09IFwiUFVUXCIgJiYgcmVxLmhlYWRlcnNbXCJjb250ZW50LXR5cGVcIl0gPT09IFwiYXBwbGljYXRpb24vanNvblwiKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgYXdhaXQgY2xpZW50LmNvbm5lY3QoKVxyXG4gICAgICAgICAgICBjb25zdCBkYiA9IGNsaWVudC5kYihcImNvbnZlcnNhdGlvbnNcIilcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGNvbnZvX3VpZCA9IHJlcS5xdWVyeVtcImNvbnZvLXVpZFwiXVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhjb252b191aWQpXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHJlcS5ib2R5Lm1lc3NhZ2UpXHJcblxyXG4gICAgICAgICAgICByZXMuc3RhdHVzKDIwMSkuc2VuZCh7fSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXSwibmFtZXMiOlsiTW9uZ29DbGllbnQiLCJ1cmkiLCJjbGllbnQiLCJyZXEiLCJyZXMiLCJtZXRob2QiLCJjb25zb2xlIiwibG9nIiwicXVlcnkiLCJzdGF0dXMiLCJqc29uIiwidGVzdCIsImVyciIsImVycm9yIiwiaGVhZGVycyIsImNvbm5lY3QiLCJkYiIsImNvbnZvX3VpZCIsImJvZHkiLCJtZXNzYWdlIiwic2VuZCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/conv.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/conv.ts"));
module.exports = __webpack_exports__;

})();