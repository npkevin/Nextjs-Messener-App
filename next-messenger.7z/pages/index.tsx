import type { NextPage } from 'next'
import SideMenu from '../components/SideMenu'
import MessengerView from '../components/Messenger/MessengerView'

import styles from '../styles/index.module.css'

const Home: NextPage = (): JSX.Element => {
    return (
        <div className={styles.container}>
            <SideMenu />
            <MessengerView />
        </div>
    )
}

export default Home
