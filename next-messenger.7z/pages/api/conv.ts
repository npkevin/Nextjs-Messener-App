import { MongoClient } from "mongodb";
import type { NextApiRequest, NextApiResponse } from "next"

const uri = "mongodb://127.0.0.1:27017/"
const client = new MongoClient(uri)

export default async (req: NextApiRequest, res: NextApiResponse) => {
    if (req.method === "GET") {

        console.log(req.query["convo-uid"])
        res.status(200).json({ test: 123456 })

    } else if (req.method === "PUT" && req.headers["content-type"] === "application/json") {
        try {
            await client.connect()
            const db = client.db("conversations")
            db.

            const convo_uid = req.query["convo-uid"]
            console.log(convo_uid)
            console.log(req.body.message)

            res.status(201).send({});
        }
        catch (err) {
            console.error(err)
            return;
        }
    }
}